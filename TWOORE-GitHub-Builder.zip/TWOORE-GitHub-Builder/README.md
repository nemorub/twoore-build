# TWOORE GitHub Builder

Este paquete deja GitHub Actions encargado de compilar:

- TWOORE Desktop + Mining Center (Qt5)
- `twoored`
- `twoore-cli`
- CKPool
- launcher `run-twoore-desktop.sh`
- `SHA256SUMS.txt`

## Uso

Copia el contenido de esta carpeta a tu repositorio `nemorub/twoore-build`.

Después abre GitHub:

1. **Actions**
2. **Build TWOORE Desktop + Mining Center**
3. **Run workflow**
4. Espera a que termine
5. Descarga el artifact **TWOORE-Desktop-MiningCenter-linux-x86_64**

El artifact contiene un `.tar.gz` listo para extraer en Ubuntu/WSL.

## Ejecutar después de descargar

```bash
mkdir -p ~/twoore-desktop-github
cd ~/twoore-desktop-github
tar -xzf TWOORE-Desktop-MiningCenter-linux-x86_64.tar.gz
./run-twoore-desktop.sh
```

El launcher utiliza por defecto:

- `~/twoore-mainnet`
- `~/twoore-mainnet/twoore.conf`
- `-txindex=0`

CKPool compilado queda en:

```text
ckpool/ckpool
```
